library(testthat)
library(packyak)

test_check("packyak")
